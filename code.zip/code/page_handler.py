# [START imports]
import os
import urllib
import json
import jinja2
import webapp2
from requests import requests
from google.appengine.api import users
from google.appengine.ext.webapp import template
from google.appengine.ext import ndb
from gaesessions import get_current_session

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)
# [END imports]

# [START form_key]
def form_key(id):
    return ndb.Key('Form', id)
# [END form_key]

# [START Form]
class Form(ndb.Model):
    fever = ndb.StringProperty(indexed=False)
    cough = ndb.StringProperty(indexed=False)
    breath = ndb.StringProperty(indexed=False)
    muscle = ndb.StringProperty(indexed=False)
    tired = ndb.StringProperty(indexed=False)
    nasal = ndb.StringProperty(indexed=False)
    throat = ndb.StringProperty(indexed=False)
    nausea = ndb.StringProperty(indexed=False)
    taste = ndb.StringProperty(indexed=False)
    chills = ndb.StringProperty(indexed=False)
    isolate = ndb.StringProperty(indexed=False)
# [END Form]

# [START create_entity]
def create_entity(id, form_data):
    element = Form(id=id, fever=form_data['fever'], cough=form_data['cough'], breath=form_data['breath'], muscle=form_data['muscle'], tired=form_data['tired'],
                   nasal=form_data['nasal'], throat=form_data['throat'], nausea=form_data['nausea'], taste=form_data['taste'], chills=form_data['chills'], isolate=form_data['isolate'])
    element.put()
    return element
# [END create_entity]

# [START FormHandler]
class FormHandler(webapp2.RequestHandler):
    def post(self):
        session = get_current_session()
        form_data = {
                'fever': self.request.get('fever'),
                'cough': self.request.get('cough'),
                'breath': self.request.get('breath'),
                'muscle': self.request.get('muscle'),
                'tired': self.request.get('tired'),
                'nasal': self.request.get('nasal'),
                'throat': self.request.get('throat'),
                'nausea': self.request.get('nausea'),
                'taste': self.request.get('taste'),
                'chills': self.request.get('chills'),
                'isolate': self.request.get('isolate')
            }
        # user_id = self.request.get('user_id')
        # state = self.request.get('state').strip().upper()
        if any([True for key,value in form_data.items() if value == '']):
            template = JINJA_ENVIRONMENT.get_template('index.html')
            self.response.write(template.render({'message':'Please answer all the questions!'}))
        else:
            element = create_entity('sumeetYedula', form_data)
            # Data studio code
            if any([True for key,value in form_data.items() if value == 'yes']):
                # send the json data
                session['name'] = 'sumeet'
                url = 'https://bw7plu7pni.execute-api.us-east-1.amazonaws.com/lambda_request_handler'
                myobj = [{'state': 'AL'}]
                json_data = requests.post(url, data = myobj)
                self.response.headers['Content-Type'] = 'application/json'
                self.redirect('/map')
            else:
                template = JINJA_ENVIRONMENT.get_template('index.html')
                self.response.write(template.render({'message':'No covid!'}))
                print("No Covid")
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('index.html')
        self.response.write(template.render())
# [END FormHandler]

# [START MapHandler]
class MapHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('locations.html')
        self.response.write(template.render())
    def post(self):
        session = get_current_session()
        # receive and assign the json data
        message={'name':session['name']}
        template = JINJA_ENVIRONMENT.get_template('locations.html')
        self.response.write(template.render(message)) 
# [END MapHandler]

# [START app]
app = webapp2.WSGIApplication([
    ('/', FormHandler),
    ('/map', MapHandler),
], debug=True)
# [END app]
            